package scc.simon.sucursales;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class productos extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_productos2);
    }

    public void buton_su(View view){
        Intent BSU = new Intent(this, MainActivity.class);
        startActivity(BSU);
    }
    public void buton_se(View view){
        Intent BSE = new Intent(this, servicios.class);
        startActivity(BSE);
    }
}