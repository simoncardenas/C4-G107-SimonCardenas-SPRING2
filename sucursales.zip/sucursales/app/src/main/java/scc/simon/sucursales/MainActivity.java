package scc.simon.sucursales;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }



    // metodo boton
    public void  buton_productos(View view){
        Intent Bp =new Intent(this,productos.class);
                startActivity(Bp);
    }
    public void buton_se(View view){
        Intent BSE = new Intent(this, servicios.class);
        startActivity(BSE);
    }

}